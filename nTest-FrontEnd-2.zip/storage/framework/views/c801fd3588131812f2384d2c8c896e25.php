<?php $__env->startSection('main'); ?>
<div class="col-lg-9">
    <div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
        <div class="content">
            <div class="section-title">
                <h4 class="rbt-title-style-3">Natijalar</h4>
            </div>

            <div class="rbt-dashboard-table table-responsive mobile-table-750">
                <table class="rbt-table table table-borderless">
                    <thead>
                        <tr>
                            <th>T/r</th>
                            <th>Fanlar</th>
                            <th>Variantlar</th>
                            <th>Test</th>
                            <th>Yozma ish</th>
                            <th>Umumiy ball</th>
                            <th>Daraja</th>
                            <th>Sana</th>
                            <th>Tavsiyalar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $final_test_result_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $details = collect($test['details'] ?? []);
                                $totalQuestions = $details->count();
                                $correctAnswers = $details->where('is_correct', '1')->count();
                                $testScore = $totalQuestions > 0 ? round(($correctAnswers / $totalQuestions) * 100, 0) : 0; 

                                $writtenDetails = $details->whereIn('testable_type', ['esse', 'double_fill_gap']);
                                $writtenScore = $writtenDetails->where('is_correct', '1')->count(); 
                                $overallScore = $totalQuestions > 0 ? round((($correctAnswers + $writtenScore) / ($totalQuestions + $writtenDetails->count())) * 100, 0) : 0;

                                $level = 'A1';
                                if ($overallScore >= 57 && $overallScore <= 65) $level = 'A2';
                                elseif ($overallScore >= 66 && $overallScore <= 75) $level = 'B1';
                                elseif ($overallScore >= 76 && $overallScore <= 85) $level = 'B2';
                                elseif ($overallScore > 85) $level = 'C';

                                $comments = $details->where('is_correct', '0')->pluck('comment')->filter()->values()->toArray();
                                $commentsHtml = collect($comments)->map(fn($comment) => "<p class='mb--10'>{$comment}</p>")->implode('');
                                $commentsHtml = $commentsHtml ?: '<p class="mb--10">Tavsiyalar mavjud emas.</p>';

                                $date = $test['finished_at'] ?? 'N/A';
                                $formattedDate = $date !== 'N/A' ? date('d.m.Y', strtotime($date)) : 'N/A';
                            ?>

                            <tr data-test-id="<?php echo e($test['id']); ?>"
                                data-fan="<?php echo e(e(data_get($test, 'final_test.subject.name', 'Noma\'lum fan'))); ?>"
                                data-variant="<?php echo e(e(data_get($test, 'final_test.name', 'Noma\'lum variant'))); ?>"
                                data-comments='<?php echo json_encode($commentsHtml, 15, 512) ?>'>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(data_get($test, 'final_test.subject.name', 'Noma\'lum fan')); ?></td>
                                <td><?php echo e(data_get($test, 'final_test.name', 'Noma\'lum variant')); ?></td>
                                <td><?php echo e($testScore); ?></td>
                                <td><?php echo e($writtenScore); ?></td>
                                <td><?php echo e($overallScore); ?></td>
                                <td><?php echo e($level); ?></td>
                                <td><?php echo e($formattedDate); ?></td>
                                <td>
                                    <a class="rbt-btn btn-xs bg-primary-opacity radius-round tavsiya-btn"
                                       href="#" title="Tavsiya" role="button"
                                       data-bs-toggle="modal" data-bs-target="#tavsiyaModal">
                                        <i class="feather-eye pl--0"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            
            <div class="row">
                <?php if($final_test_result_data->hasPages()): ?>
                    <div class="col-lg-12 mt--40">
                        <nav>
                            <ul class="rbt-pagination">
                                
                                <?php if($final_test_result_data->onFirstPage()): ?>
                                    <li class="disabled"><span><i class="feather-chevron-left"></i></span></li>
                                <?php else: ?>
                                    <li><a href="<?php echo e($final_test_result_data->previousPageUrl()); ?>"><i class="feather-chevron-left"></i></a></li>
                                <?php endif; ?>

                                
                                <?php $__currentLoopData = $final_test_result_data->getUrlRange(1, $final_test_result_data->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page == $final_test_result_data->currentPage()): ?>
                                        <li class="active"><a href="#"><?php echo e($page); ?></a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                                <?php if($final_test_result_data->hasMorePages()): ?>
                                    <li><a href="<?php echo e($final_test_result_data->nextPageUrl()); ?>"><i class="feather-chevron-right"></i></a></li>
                                <?php else: ?>
                                    <li class="disabled"><span><i class="feather-chevron-right"></i></span></li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<div class="rbt-team-modal modal fade rbt-modal-default" id="tavsiyaModal" tabindex="-1" aria-labelledby="tavsiyaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tavsiyalar</h5>
                <button type="button" class="rbt-round-btn" data-bs-dismiss="modal" aria-label="Close">
                    <i class="feather-x"></i>
                </button>
            </div>
            <div class="modal-body">
                <div id="modal-content" class="mb--20" style="font-size:16px!important;"></div>
                <div id="modal-comments"></div>
                <p class="mt--40" style="color:#333; font-style:italic; font-size:16px; font-weight:600;">
                    Sizning kelgusi ishlaringizda muvaffaqiyat tilaymiz!
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const modalEl = document.getElementById('tavsiyaModal');
    const modalContent = document.getElementById('modal-content');
    const modalComments = document.getElementById('modal-comments');
    const tavsiyaBtns = document.querySelectorAll('.tavsiya-btn');

    const modalInstance = new bootstrap.Modal(modalEl, {
        backdrop: true,
        keyboard: true
    });

    tavsiyaBtns.forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const row = this.closest('tr');
            if (!row) return;

            const fan = row.dataset.fan;
            const variant = row.dataset.variant;
            const commentsHtml = JSON.parse(row.dataset.comments || '""');

            modalContent.innerHTML = `<strong>${fan}</strong> fanidan <strong>${variant}</strong> bo‘yicha tavsiyalar:`;
            modalComments.innerHTML = commentsHtml;

            modalInstance.show();
        });
    });
    modalEl.addEventListener('hidden.bs.modal', function () {
        modalContent.innerHTML = '';
        modalComments.innerHTML = '';
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nTest-FrontEnd\resources\views/user/results.blade.php ENDPATH**/ ?>