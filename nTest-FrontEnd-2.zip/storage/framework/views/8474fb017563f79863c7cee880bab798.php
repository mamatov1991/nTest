<?php $__env->startSection('index'); ?>
<div class="rbt-overlay-page-wrapper">
        <div class="breadcrumb-image-container breadcrumb-style-max-width">
            <div class="breadcrumb-content-top text-center">
            <?php $__currentLoopData = $news_single; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3 class="title"><?php echo e($new_one['title'] ?? 'No title available'); ?></h3>
                <ul class="meta-list justify-content-center mb--10">
                <li><i class="feather-calendar"></i><?php echo e(date('d.m.Y', strtotime($new_one['created_at']))); ?></li>
                <li><i class="feather-eye"></i><?php echo e($new_one['views']); ?></li>
                </ul>
            </div>
        </div>

        <div class="rbt-blog-details-area rbt-section-gapBottom breadcrumb-style-max-width">
            <div class="blog-content-wrapper rbt-article-content-wrapper">
                <div class="content pb--30">
                <?php echo $new_one['content']; ?>


                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr>
                <div class="related-post pt--30">
                    <div class="section-title text-start mb--40">
                        <h4 class="title">Yangiliklar</h4>
                    </div>

                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-lg-4">
                        <!-- Start News  -->
                        <div class="rbt-card event-grid-card variation-01 rbt-hover p-4">
                            <div class="rbt-card-img">
                                <a href="/news-view/<?php echo e($new['id']); ?>">
                                    <img src="<?php echo e($new['image']); ?>" alt="News image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                            <li><i class="feather-calendar"></i><?php echo e(date('d.m.Y', strtotime($new['created_at']))); ?></li>
                                            <li><i class="feather-eye"></i><?php echo e($new['views']); ?></li>
                                        </ul>
                                <h4 class="rbt-card-title mb--5"><a href="/news-view/<?php echo e($new['id']); ?>"><?php echo e($new['title']); ?></a></h4>
                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-gradient hover-icon-reverse" href="/news-view/<?php echo e($new['id']); ?>" style="float:right;">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Batafsil</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- End News  -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>


    <div class="rbt-separator-mid">
        <div class="container">
            <hr class="rbt-separator m-0">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.sub-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nTest-FrontEnd\resources\views/main/news-view.blade.php ENDPATH**/ ?>