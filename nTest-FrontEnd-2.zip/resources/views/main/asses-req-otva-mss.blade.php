@extends('main.sub-layout')

@section('index')
     

        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <div class="breadcrumb-content-top text-center mt--60 mb--50">
                <h3 class="title">Ona tili va adabiyot (milliy sertifikat) spetsifikatsiyasi</h3>
            </div>
                        <div class="content pb--30">
                        <iframe src="../assets/uploads/ona_tili_va_adabiyot_milliy_sertifikat_spetsifikatsiyasi.pdf" frameborder="0" width="100%" height="800px"></iframe>
                        </div>
                </div>
            </div>
        </div>
    


    <div class="rbt-separator-mid">
        <div class="container">
            <hr class="rbt-separator m-0">
        </div>
    </div>
@endsection