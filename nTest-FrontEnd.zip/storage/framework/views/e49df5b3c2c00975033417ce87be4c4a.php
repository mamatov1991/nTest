<?php $__env->startSection('main'); ?>
<div class="row g-5">
                        

                        <div class="col-lg-12">
                        <h5 class="text-center">
                        <?php echo e($final_test_result_data['final_test']['subject']['name'] ?? ''); ?> (<?php echo e($final_test_result_data['final_test']['type'] ?? ''); ?>)
                        </h5>
                            <div class="rbt-dashboard-content bg-color-white rbt-shadow-box mb--60">
                                <div class="inner">
                            <div class="content">
                               
                        <form id="quiz-form" class="quiz-form-wrapper">
                            <!-- Start Single Quiz  -->
                            <div id="question-1" class="question">
                                <div class="quize-top-meta">
                                    <div class="quize-top-left">
                                        <span>Yakuniy test: <strong><?php echo e($final_test_result_data['final_test']['name'] ?? ''); ?></strong></span>
                                        <span>Savollar soni: <strong><?php echo e(count($final_test_result_data['details'] ?? [])); ?> ta</strong></span>

                                    </div>
                                    <div class="quize-top-right">
                                  

                                    </div>

                                </div>
                                <hr>
                                <nav>
                                    <div class="nav-links mb--30">
                                        <h5 class="text-center">Natija</h5>
                                    </div>
                                </nav>
                                <table class="rbt-table table table-borderless">
                                            <thead>
                                                <tr>
                                                    <th>Variant</th>
                                                    <th>Jami test soni</th>
                                                    <th>Yopiq testlar soni</th>
                                                    <th>To‘g‘ri javoblar</th>
                                                    <th>Noto‘g‘ri javoblar</th>
                                                    <th>Sana</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                                $correct = 0;
                                                $incorrect = 0;
                                                $closedQuestions = 0;
                                                $score=0;
                                                $totalQuestions = count($final_test_result_data['details'] ?? []);
                                                foreach ($final_test_result_data['details'] ?? [] as $detail) {
                                                    if ($detail['is_correct'] == 1) {
                                                        $correct++;
                                                    } else if (($detail['is_correct'] == 0) && ($detail['testable_type'] == 'choose_option')) {
                                                        $incorrect++;
                                                    }
                                                    if ($detail['testable_type'] == 'choose_option') {
                                                        $closedQuestions++;
                                                        $score+=$detail['score'];
                                                    }
                                                }
                                            ?>
                                            <tr>
                                                <td><?php echo e($final_test_result_data['final_test']['name'] ?? ''); ?></td>
                                                <td><?php echo e($totalQuestions); ?> ta</td>
                                                <td><?php echo e($closedQuestions); ?> ta</td>
                                                <td><?php echo e($correct); ?> ta</td>
                                                <td><?php echo e($incorrect); ?> ta</td>
                                                <td><?php echo e(\Carbon\Carbon::parse($final_test_result_data['start_at'])->format('d.m.Y')); ?></td>
                                            </tr>
                                        </tbody>

                                                                                </table>
                                                                                <p><b>Izoh: </b> <i> Yuqoridagi to‘g‘ri va noto‘g‘ri javoblar yopiq testlar soniga nisbatan hisoblangan. Ochiq testlar va esse natijalari <b>3 kun</b> ichida tekshiriladi. Umumiy ball va darajangizni <b><a href="/user/results">Natijalar</a></b> bo‘limidan ko‘rishingiz mumkin bo‘ladi.</i></p>
                                                                    <hr>
                                                                    <h5 class="text-center">Hisobot</h5>
                                                                    <div class="rbt-single-quiz">
                                                                    <?php $__currentLoopData = $final_test_result_data['details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($result['testable_type'] == 'choose_option'): ?>
                                                <div class="rbt-single-quiz mt--40">
                                                    <h5 class="result-ques"><?php echo e($loop->iteration); ?>. <?php echo $result['question']; ?></h5>

                                                    <div class="row g-3 mt--10">
                                                        <?php $__currentLoopData = $result['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionIndex => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                // Foydalanuvchi tanlagan variant
                                                                $isUserAnswer = $result['user_answer'] == $option['id'];
                                                                // To‘g‘ri variant
                                                                $isCorrect = $option['is_correct'];
                                                            ?>

                                                            <div class="col-lg-12">
                                                                <p class="rbt-checkbox-wrapper mb--5"
                                                                style="background-color:
                                                                    <?php if($isUserAnswer && $isCorrect): ?> rgb(210, 253, 170) 
                                                                    <?php elseif($isUserAnswer && !$isCorrect): ?> rgb(253, 170, 170) 
                                                                    <?php elseif(!$isUserAnswer && $isCorrect): ?> rgb(210, 253, 170) 
                                                                    <?php else: ?> transparent
                                                                    <?php endif; ?>;
                                                                    padding: 10px;">

                                                                    <input class="form-check-input" type="radio" 
                                                                        name="quiz-<?php echo e($index); ?>" 
                                                                        id="option-<?php echo e($option['id']); ?>" 
                                                                        <?php if($isUserAnswer): ?> checked <?php endif; ?> disabled>

                                                                    <label class="form-check-label" for="option-<?php echo e($option['id']); ?>">
                                                                        <?php echo e(chr(65 + $optionIndex)); ?>) <?php echo e($option['body']); ?>

                                                                    </label>

                                                                    
                                                                    <?php if($isUserAnswer && $isCorrect): ?>
                                                                        <i class="feather-check" style="float: right; color: rgb(6, 139, 35); font-size: 20px; font-weight: 600;"></i>
                                                                    <?php elseif($isUserAnswer && !$isCorrect): ?>
                                                                        <i class="feather-x" style="float: right; color: rgb(139, 6, 6); font-size: 20px; font-weight: 600;"></i>
                                                                    <?php elseif(!$isUserAnswer && $isCorrect): ?>
                                                                        <i class="feather-check" style="float: right; color: rgb(6, 139, 35); font-size: 20px; font-weight: 600;"></i>
                                                                    <?php endif; ?>
                                                                </p>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                    </div>
                    </div>

                    <div class="tutor-btn mt--40" style="float: right;">
                                    <a class="rbt-btn btn-md hover-icon-reverse" href="/user/main">
                                        <span class="icon-reverse-wrapper">
                        <span class="btn-text">Asosiy oynaga qaytish</span>
                                        <span class="btn-icon"><i class="feather-arrow-left"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-left"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            </div>
                            </div>
                            </div>
                            </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Card Style -->
    <div class="rbt-separator-mid">
        <div class="container">
            <hr class="rbt-separator m-0">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.test-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nTest-FrontEnd\resources\views/user/final-test-results.blade.php ENDPATH**/ ?>