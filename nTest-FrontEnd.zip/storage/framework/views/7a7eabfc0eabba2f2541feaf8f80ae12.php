

<?php $__env->startSection('main'); ?>
<div class="col-lg-9">
                            <div class="rbt-dashboard-content bg-color-white rbt-shadow-box mb--60">
                                <div class="content">
                                    <div class="section-title">
                                        <h4 class="rbt-title-style-3">
                                          <?php
                                          $testType = null;
                                          $chapterId = null;                                        
                                        ?>
                                        <?php echo e($subjectName ?? 'Nomaʼlum fan'); ?>

                                         </h4>
                                    </div>
                                    <div class="row g-5 mb--30">
                        <h4 class="title text-center">Quyidagilarni tanlang</h4>
                        <form action="/user/select-test-type/<?php echo e($subjectId); ?>" method="POST" class="rbt-profile-row rbt-default-form row row--15">
    <?php echo csrf_field(); ?>

    <div class="col-lg-4 col-md-4 col-sm-4 col-12 mb--20">
        <div class="filter-select rbt-modern-select">
            <select id="testCategory" name="testCategory" class="w-100 selectpicker">
                <option selected disabled>Test turini tanlang *</option>
                <?php $__currentLoopData = $test_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($types['id']); ?>"><?php echo e($types['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-lg-4 col-md-4 col-sm-4 col-12 mb--20">
        <div class="filter-select rbt-modern-select">
            <select id="testType" name="testType" class="w-100 selectpicker">
                <option value=""  <?php echo e(!$testType ? 'selected' : ''); ?> disabled>Yakuniy yoki bo‘limlar *</option>
                <option value="yakuniy" <?php echo e($testType === 'yakuniy' ? 'selected' : ''); ?>>Yakuniy test</option>
                <option value="bolim" <?php echo e($testType === 'bolim' ? 'selected' : ''); ?>>Bo‘limlar bo‘yicha test</option>
            </select>
        </div>
    </div>

    <div id="childSelectWrap" class="col-lg-4 col-md-4 col-sm-4 col-12 mb--20 <?php echo e($testType === 'bolim' ? '' : 'd-none'); ?>">
        <div class="filter-select rbt-modern-select">
            <select id="childSelect_chapter" name="chapterId" class="w-100 selectpicker">
                <option selected disabled>Bo‘limni tanlang *</option>
                <?php if(!empty($chapters)): ?>
                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($chapter['id']); ?>" <?php echo e(($chapterId ?? null) == $chapter['id'] ? 'selected' : ''); ?>><?php echo e($chapter['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
    </div>
    <div id="childSelectWrap1" class="col-lg-4 col-md-4 col-sm-4 col-12 mb--20 <?php echo e($testType === 'yakuniy' ? '' : 'd-none'); ?>">
        <div class="filter-select rbt-modern-select ">
            <select id="childSelect_final_test" name="finalTestId" class="w-100 selectpicker">
                <option selected disabled>Variantni tanlang *</option>
                <?php if(!empty($final_tests)): ?>
                <?php $__currentLoopData = $final_tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $final_test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($final_test['id']); ?>" <?php echo e(($finalTestId ?? null) == $final_test['id'] ? 'selected' : ''); ?>><?php echo e($final_test['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
    </div>
<input type="hidden" name="subjectId" value="<?php echo e($subjectId); ?>">
    <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt--30">
        <div class="rbt-form-group">
            <button type="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse" style="float: right; margin-right: 6px;">
                <span class="icon-reverse-wrapper">
                    <span class="btn-text">Testni boshlash</span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                </span>
            </button>
        </div>
    </div>
</form>

                                    </div>
                                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Card Style -->
    <div class="rbt-separator-mid">
        <div class="container">
            <hr class="rbt-separator m-0">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$(function () {
    $('.selectpicker').selectpicker({
        noneSelectedText: 'Tanlanmagan'
    });

    $('#testCategory').on('changed.bs.select', function () {
        let testCategory = $(this).val();
        let subjectId = "<?php echo e($subjectId); ?>";

        $.ajax({
            url: `/user/tests-by-category/${subjectId}`,
            method: 'GET',
            data: { testCategory: testCategory },
            success: function (response) {
                let $chapterSelect = $('#childSelect_chapter');
                $chapterSelect.empty().append('<option disabled selected>Bo‘limni tanlang *</option>');
                response.chapters.forEach(ch => {
                    $chapterSelect.append(`<option value="${ch.id}">${ch.name}</option>`);
                });
                $chapterSelect.selectpicker('refresh');

                let $finalSelect = $('#childSelect_final_test');
                $finalSelect.empty().append('<option disabled selected>Variantni tanlang *</option>');
                response.final_tests.forEach(ft => {
                    $finalSelect.append(`<option value="${ft.id}">${ft.name}</option>`);
                });
                $finalSelect.selectpicker('refresh');
            }
        });
    });

    $('#testType').on('changed.bs.select', function () {
        let val = $(this).val();
        if (val === 'bolim') {
            $('#childSelect_chapter').closest('.col-lg-4').removeClass('d-none');
            $('#childSelect_final_test').closest('.col-lg-4').addClass('d-none');
        } else if (val === 'yakuniy') {
            $('#childSelect_final_test').closest('.col-lg-4').removeClass('d-none');
            $('#childSelect_chapter').closest('.col-lg-4').addClass('d-none');
        } else {
            $('#childSelect_chapter').closest('.col-lg-4').addClass('d-none');
            $('#childSelect_final_test').closest('.col-lg-4').addClass('d-none');
        }
    });
});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.sub-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nTest-FrontEnd\resources\views/user/select-test-type.blade.php ENDPATH**/ ?>