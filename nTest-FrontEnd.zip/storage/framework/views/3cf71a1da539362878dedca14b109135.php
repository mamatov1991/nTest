    

    <?php $__env->startSection('main'); ?>
    <div class="row g-5">         

    <div class="col-lg-12">
    <h5 class="text-center"><?php echo e($subject_name); ?></h5>
    <div class="rbt-dashboard-content bg-color-white rbt-shadow-box mb--60">
    <div class="inner">
    <div class="content">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <form id="quiz-form" class="quiz-form-wrapper">
    <input type="hidden" name="test_id" value="<?php echo e($test_id); ?>">
    <div class="quize-top-meta mb-3">
    <div class="quize-top-left">
    <span>Bo‘lim nomi: <strong><?php echo e($chapter_name); ?></strong></span>
    <span>Savollar soni: <strong><?php echo e(count($chapter_questions)); ?> ta</strong></span>
    </div>
    <div class="quize-top-right">
    <span>Vaqt: <strong id="countdown"><?php echo e(gmdate('i:s', $remaining_time)); ?></strong></span>
    </div>
    </div>
    <hr>
    <div class="row">
    <div class="col-lg-12">
    <nav>
    <ul id="quiz-nav" class="rbt-pagination justify-content-start">
    <?php $__currentLoopData = $chapter_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
    <a href="#" class="nav-btn" data-index="<?php echo e($loop->iteration); ?>"><?php echo e($loop->iteration); ?></a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </nav>
    </div>
    </div>
    <?php $__currentLoopData = $chapter_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="question d-none" id="question-<?php echo e($loop->iteration); ?>">
    <div class="question-text mt--30">
    <span><?php echo e($loop->iteration); ?>.</span> <span><?php echo $question['id']; ?> <?php echo $question['question'] ?? 'Savol matni yo‘q'; ?></span>
    </div>
    <div class="row g-3 mt-2">
    <?php $__currentLoopData = $question['options'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optIndex => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-12">
    <p class="rbt-checkbox-wrapper mb-2">
    <input class="form-check-input answer-option"
    type="radio"
    name="question_<?php echo e($loop->iteration); ?>"
    data-question-id="<?php echo e($question['id'] ?? 'unknown'); ?>"
    value="<?php echo e($option['id'] ?? ''); ?>"
    id="option-<?php echo e($option['id'] ?? uniqid()); ?>">
    <label class="form-check-label" for="option-<?php echo e($option['id'] ?? uniqid()); ?>">
    <?php echo e(chr(65 + $optIndex)); ?>) <?php echo e($option['body'] ?? 'Variant yo‘q'); ?>

    </label>
    </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="submit-btn mt-4">
    <button type="button" id="submit-test" class="rbt-btn btn-gradient hover-icon-reverse" style="float:right; padding-left: 50px;">
    <span class="icon-reverse-wrapper">
    <span class="btn-text">Testni tugatish</span>
    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
    </span>
    </button>
    </div>
    </form>

    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>

    <!-- End Card Style -->
    <div class="rbt-separator-mid">
    <div class="container">
    <hr class="rbt-separator m-0">
    </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
    let currentQuestion = 1;
    const totalQuestions = <?php echo e(count($chapter_questions)); ?>;
    const isNewTest = <?php echo e($isNewTest ? 'true' : 'false'); ?>;
    let answers;
    let remainingTime;
    let countdownInterval;

    // Yangi test bo'lsa, localStorage'ni tozalash
    if (isNewTest) {
    localStorage.removeItem('quizAnswers');
    localStorage.removeItem('remainingTime');
    answers = {};
    remainingTime = <?php echo e($remaining_time); ?>;
    const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
    history.replaceState({}, document.title, newUrl);
    } else {
    answers = JSON.parse(localStorage.getItem('quizAnswers')) || <?php echo e(json_encode($userAnswers)); ?> || {};
    remainingTime = localStorage.getItem('remainingTime') ? parseInt(localStorage.getItem('remainingTime')) : <?php echo e($remaining_time); ?>;
    }

    const submitBtn = document.getElementById('submit-test');
    const btnText = submitBtn ? submitBtn.querySelector('.btn-text') : null;
    const countdownElem = document.getElementById('countdown');

    // Vaqtni formatlash
    function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    // Countdown funksiyasi
    function startCountdown() {
    if (!countdownElem) return;
    countdownInterval = setInterval(() => {
    remainingTime--;
    if (remainingTime <= 0) {
    clearInterval(countdownInterval);
    alert("Vaqt tugadi!");
    submitTest();
    } else {
    countdownElem.textContent = formatTime(remainingTime);
    localStorage.setItem('remainingTime', remainingTime);
    }
    }, 1000);
    }

    // Savolni ko'rsatish
    function showQuestion(index) {
    const questionElements = document.querySelectorAll('.question');
    if (!questionElements.length) return;

    questionElements.forEach(q => q.classList.add('d-none'));
    const questionElem = document.getElementById('question-' + index);
    if (!questionElem) return;
    questionElem.classList.remove('d-none');
    questionElem.querySelectorAll('.answer-option').forEach(opt => {
    opt.checked = answers[opt.dataset.questionId] === opt.value;
    });

    const navButtons = document.querySelectorAll('.rbt-pagination li a');
    navButtons.forEach(btn => {
    btn.parentElement.classList.remove('active');
    const questionId = document.getElementById('question-' + btn.dataset.index)?.querySelector('.answer-option')?.dataset.questionId;
    if (questionId && answers[questionId]) {
    btn.classList.add('answered');
    } else {
    btn.classList.remove('answered');
    }
    });

    const navBtn = document.querySelector(`.rbt-pagination li a[data-index="${index}"]`);
    if (navBtn) {
    navBtn.parentElement.classList.add('active');
    }
    currentQuestion = parseInt(index);
    if (btnText) {
    btnText.textContent = currentQuestion === totalQuestions ? 'Testni tugatish' : 'Keyingi';
    }
    }

    // Javoblarni yig'ish
    const answerOptions = document.querySelectorAll('.answer-option');
    if (answerOptions.length > 0) {
    answerOptions.forEach(opt => {
    opt.addEventListener('change', function() {
    const qId = this.dataset.questionId;
    const value = this.value;
    answers[qId] = value; // Har bir tanlovni alohida saqlash
    localStorage.setItem('quizAnswers', JSON.stringify(answers));
    const currentNavBtn = document.querySelector(`.rbt-pagination li a[data-index="${currentQuestion}"]`);
    if (currentNavBtn) {
    currentNavBtn.classList.add('answered');
    }
    console.log('Updated answers:', answers); // Debug uchun
    });
    });
    }

    // Navigatsiya tugmalari
    const navButtons = document.querySelectorAll('.rbt-pagination li a');
    if (navButtons.length > 0) {
    navButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
    e.preventDefault();
    showQuestion(this.dataset.index);
    });
    });
    }

    // Submit funksiyasi
    function submitTest() {
    const testId = <?php echo e($test_id ?? 'null'); ?>;
    if (!testId || isNaN(parseInt(testId))) {
    alert("Test ID noto'g'ri! Sahifani qayta yuklang.");
    return;
    }

    const payload = {
    test_id: parseInt(testId),
    answers: Object.keys(answers)
    .filter(qId => answers[qId]) // faqat javob berilganlarini olamiz
    .map(qId => ({ 
    id: parseInt(qId),      // question_id raqam
    answer: answers[qId]    // option_id string (masalan: "68d3d5094b7d1")
    }))
    };


    if (payload.answers.length === 0) {
    alert("Iltimos, kamida bitta savolga javob bering!");
    return;
    }

    console.log('Payload:', payload); // Debug uchun

    fetch("<?php echo e(route('user.submit.test')); ?>", {
    method: "POST",
    headers: {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    },
    body: JSON.stringify(payload)
    })
    .then(res => {
    console.log('Response status:', res.status);
    if (!res.ok) {
    return res.json().then(data => {
    throw new Error(data.message || 'Server xatosi: ' + JSON.stringify(data.errors || {}));
    });
    }
    return res.json();
    })
    .then(data => {
    if (data.success) {
    let answerDetails = payload.answers.map(item => 
    `Savol ID: ${item.id}, Javob: ${item.answer}`
    ).join('\n');
    // alert(`${data.message} \n\nYuborilgan javoblar:\n${answerDetails}\n\nNatijalar:\nScore: ${data.data?.score || 'Noma\'lum'}`);
    } else {
    // alert("API xatosi: " + (data.message || 'Noma\'lum xato'));
    }
    localStorage.removeItem('quizAnswers');
    localStorage.removeItem('remainingTime');
    clearInterval(countdownInterval);
    window.location.href = "<?php echo e(route('user.test.results')); ?>";
    })
    .catch(err => {
    console.error('Error:', err.message);
    });
    }

    // Submit tugmasi
    if (submitBtn) {
    submitBtn.addEventListener('click', function(e) {
    e.preventDefault();
    if (currentQuestion < totalQuestions) {
    showQuestion(currentQuestion + 1);
    } else {
    const unanswered = [];
    for (let i = 1; i <= totalQuestions; i++) {
    const qId = document.getElementById('question-' + i)?.querySelector('.answer-option')?.dataset.questionId;
    if (qId && !answers[qId]) {
    unanswered.push(i);
    }
    }

    if (unanswered.length > 0) {
    Swal.fire({
    title: 'Javob berilmagan savollar mavjud!',
    text: 'Testni yakunlamoqchimisiz?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ha, yakunlash',
    cancelButtonText: 'Yo‘q, davom etish'
    }).then((result) => {
    if (result.isConfirmed) {
    submitTest();
    } else {
    showQuestion(unanswered[0]);
    }
    });
    } else {
    submitTest();
    }
    }
    });
    }

    // Dastlabki holatni o'rnatish
    showQuestion(1);
    countdownElem.textContent = formatTime(remainingTime);
    startCountdown();
    });
    </script>

    <!-- <script>
    document.querySelectorAll('.answer-option').forEach(opt => {
    console.log('Question ID:', opt.dataset.questionId, 'Value:', opt.value);
    });
    </script> -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user.test-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nTest-FrontEnd\resources\views/user/test-questions.blade.php ENDPATH**/ ?>