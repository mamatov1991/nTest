<?php

return [
    'base_url' => env('API_BASE_URL', 'https://api.ntest.uz'),
    'token'    => env('API_TOKEN', ''),
];