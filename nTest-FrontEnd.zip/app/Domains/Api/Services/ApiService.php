<?php

namespace App\Domains\Api\Services;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class ApiService
{
    /**
     * GET so'rov yuborish
     */
    public static function getFromApi($endpoint)
    {
        $baseUrl = rtrim(config('api.base_url'), '/');
        $fullUrl = "{$baseUrl}/api/{$endpoint}";

        $client = new Client([
            'verify' => false,
            'http_errors' => false,
        ]);

        try {
            $response = $client->request('GET', $fullUrl, [
                'headers' => [
                    'Authorization' => 'Bearer ' . config('api.token'),
                    'Accept-Language' => app()->getLocale(),
                    'Accept' => 'application/json',
                ],
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('GET API Error: ' . $e->getMessage(), [
                'url' => $fullUrl,
                'code' => $e->getCode(),
            ]);
            throw $e;
        }
    }

    /**
     * Foydalanuvchi tokeni bilan GET so'rov
     */
    public static function getFromApiForUser($endpoint)
    {
        $baseUrl = rtrim(config('api.base_url'), '/');
        $fullUrl = "{$baseUrl}/api/{$endpoint}";

        $client = new Client([
            'verify' => false, //
            'http_errors' => false,
        ]);

        try {
            $response = $client->request('GET', $fullUrl, [
                'headers' => [
                    'Authorization' => 'Bearer ' . auth()->user()->token,
                    'Accept-Language' => app()->getLocale(),
                    'Accept' => 'application/json',
                ],
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('GET API (User) Error: ' . $e->getMessage(), [
                'url' => $fullUrl,
                'user_id' => auth()->id() ?? 'guest',
            ]);
            throw $e;
        }
    }

    /**
     * POST so'rov yuborish
     */
    public static function postToApi($endpoint, $data = [])
    {
        $baseUrl = rtrim(config('api.base_url'), '/');
        $fullUrl = "{$baseUrl}/api/{$endpoint}";

        $client = new Client([
            'verify' => false,
            'http_errors' => false,
        ]);

        try {
            $response = $client->request('POST', $fullUrl, [
                'headers' => [
                    'Authorization' => 'Bearer ' . config('api.token'),
                    'Accept-Language' => app()->getLocale(),
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('POST API Error: ' . $e->getMessage(), [
                'url' => $fullUrl,
                'data' => $data,
                'code' => $e->getCode(),
            ]);
            throw $e;
        }
    }

    public static function getProfileMe(): array
    {
        $base  = rtrim(config('api.base_url'), '/'); 
        $token = session('auth_token');

        $resp = Http::withToken($token)
            ->acceptJson()
            ->get("$base/profile/me");

        return $resp->json();
    }
}
